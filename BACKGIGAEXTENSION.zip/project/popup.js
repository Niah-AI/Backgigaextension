let mediaRecorder;
let audioChunks = [];
let isRecording = false;

document.addEventListener('DOMContentLoaded', () => {
  const startButton = document.getElementById('startRecording');
  const stopButton = document.getElementById('stopRecording');
  const summarizeButton = document.getElementById('summarize');
  const copyButton = document.getElementById('copy');
  const status = document.getElementById('status');
  const transcription = document.getElementById('transcription');

  startButton.addEventListener('click', startRecording);
  stopButton.addEventListener('click', stopRecording);
  summarizeButton.addEventListener('click', summarizeText);
  copyButton.addEventListener('click', copyText);

  async function startRecording() {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      mediaRecorder = new MediaRecorder(stream);
      audioChunks = [];

      mediaRecorder.ondataavailable = (event) => {
        audioChunks.push(event.data);
      };

      mediaRecorder.onstop = async () => {
        const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
        await transcribeAudio(audioBlob);
      };

      mediaRecorder.start();
      isRecording = true;
      updateUI();
      status.textContent = 'Recording...';
    } catch (error) {
      console.error('Error starting recording:', error);
      status.textContent = 'Error: Could not start recording';
    }
  }

  function stopRecording() {
    if (mediaRecorder && isRecording) {
      mediaRecorder.stop();
      mediaRecorder.stream.getTracks().forEach(track => track.stop());
      isRecording = false;
      updateUI();
      status.textContent = 'Processing audio...';
    }
  }

  async function transcribeAudio(audioBlob) {
    try {
      // In a real implementation, you would send the audio to your server
      // For demo purposes, we'll simulate a response
      await new Promise(resolve => setTimeout(resolve, 1500));
      transcription.textContent = 'This is a simulated transcription. In a production environment, this would contain the actual transcribed text from your audio recording.';
      status.textContent = 'Transcription complete';
      summarizeButton.disabled = false;
      copyButton.disabled = false;
    } catch (error) {
      console.error('Error transcribing audio:', error);
      status.textContent = 'Error: Could not transcribe audio';
    }
  }

  async function summarizeText() {
    try {
      status.textContent = 'Generating summary...';
      // In a real implementation, you would send the transcription to your server
      await new Promise(resolve => setTimeout(resolve, 1000));
      transcription.textContent = 'Summary: This is a simulated summary of the transcribed text.';
      status.textContent = 'Summary generated';
    } catch (error) {
      console.error('Error summarizing text:', error);
      status.textContent = 'Error: Could not generate summary';
    }
  }

  function copyText() {
    navigator.clipboard.writeText(transcription.textContent)
      .then(() => {
        status.textContent = 'Copied to clipboard';
        setTimeout(() => {
          status.textContent = 'Ready';
        }, 2000);
      })
      .catch(error => {
        console.error('Error copying text:', error);
        status.textContent = 'Error: Could not copy text';
      });
  }

  function updateUI() {
    startButton.disabled = isRecording;
    stopButton.disabled = !isRecording;
    summarizeButton.disabled = true;
    copyButton.disabled = true;
  }
});