export const API_CONFIG = {
  BASE_URL: 'https://api.gigadesk.com', // Your backend API URL
  ENDPOINTS: {
    AUTH: '/auth',
    TRANSCRIBE: '/transcribe',
    SUMMARIZE: '/summarize'
  }
};